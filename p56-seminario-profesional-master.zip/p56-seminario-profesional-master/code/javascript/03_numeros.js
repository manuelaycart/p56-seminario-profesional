var edad = 35
console.log(`${edad}`)
edad += 1
console.log(`${edad}`)
edad++
console.log(`${edad}`)

edad--
console.log(`${edad}`)

var precioVino = 20.50
var total = precioVino * 1.12
console.log( `Siendo el precio del vino $ ${precioVino}, el total (incluyendo el IVA) es $ ${total}.` )

var promedio = 15.6
var promedioTotal = Math.round( promedio )

console.log( promedioTotal )
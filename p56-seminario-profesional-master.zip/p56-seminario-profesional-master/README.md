# Universidad Politécnica Salesiana
## Seminario Profesional
Material del Seminario Profesional sobre Node.js + MongoDB

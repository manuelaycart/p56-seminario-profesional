## Seminario Profesional

Este seminario profesional permitirá generar la competencia para implementar aplicaciones web mediante Node.js y MongoDB.

### Sesión de Clases

- Lunes, 21/09/2020: [Comandos de GIT](https://cedia.zoom.us/rec/share/MVu8d-4C8mhumj24u2iVukuI-1rVVpWPLs4ymk2FVdIe_zjOssPL2XZBzb_iv5kC.UmjJKrQCxCj61P66)
- Martes, 22/09/2020: [GIT & Github]()

